﻿$frontPath="E:\40k\front\40k"

npm start --prefix $frontPath