﻿$backPath="E:\40k\backend\index.js"

nodemon $backPath