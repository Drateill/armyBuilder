﻿Start-Process Powershell.exe -Argumentlist "-file E:\40k\startFront.ps1"
Start-Process Powershell.exe -Argumentlist "-file E:\40k\startBack.ps1"